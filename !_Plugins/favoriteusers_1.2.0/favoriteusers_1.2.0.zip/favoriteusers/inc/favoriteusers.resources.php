<?php
/**
 * @package favoriteusers
 * @version 1.2.0
 * @author CrazyFreeMan (www.simple-website.in.ua)
 * @copyright Copyright (c) CrazyFreeMan (wwww.simple-website.in.ua)
 */
$R['favu_add_btn'] = '<a href="{$addurl}" class="ajax green" rel="get-{$favu_id}">{$addtofav}</a>';
$R['favu_delete_btn'] = '<a href="{$deleteurl}" class="ajax red" rel="get-{$favu_id}">{$deletefromfav}</a>';
$R['favu_limit'] = '<p class="red">{$text}</p>';
$R['favu_infavu'] = '<span class="green">{$text}</span>';