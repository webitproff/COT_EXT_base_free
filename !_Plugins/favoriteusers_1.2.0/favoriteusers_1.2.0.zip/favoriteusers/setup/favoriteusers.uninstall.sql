/* Drops all favoriteusers data completely */
DROP TABLE IF EXISTS `cot_favorite_users`;